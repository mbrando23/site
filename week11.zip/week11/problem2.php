<html>

	<head>
		<title>Problem #2: Date and Time</title>
	</head>
	
	<body>
		
		<!-- 
      Write a PHP program to display the current date and time. PHP has the ability to display the data and time 
      in many different formats. Please take time to find a format that is appealing to you. One possible output is:

      Tuesday, May 19th 08:30:27am

		-->
		
		<?php
			
			/* Echos the date
				h : 12 hr format
				H : 24 hr format
				i : Minutes
				s : Seconds
				u : Microseconds
				a : Lowercase am or pm
				l : Full text for the day
				F : Full text for the month
				j : Day of the month
				S : Suffix for the day st, nd, rd, etc.
				Y : 4 digit year
			*/

			echo date('l, F jS Y h:ia');
			
      ?>

	</body>
	
</html>