<html>

	<head>
		<title>Problem #3: Reflect</title>
	</head>
	
	<body>
		
		<!-- 
      This will be the first problem where we accept input into our PHP program from another source. 
      In this case, the HTML page calling problem3.php will send one parameter using the post method. 
      You are to put the user text into a paragraph in a simple HTML page.
		-->
		
		<?php
			
			$userInput = $_POST['input3'];
									
			echo "<p>\"$userInput\" is the most difficult program to write in a computer language. </p>";         			
		  
      ?>

	</body>
	
</html>