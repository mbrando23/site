<html>

	<head>
		<title>Week 11 : Problem 1</title>
	</head>
	
	<body>
		
		<!-- 

      Often "Hello World" is the most difficult program to write in a language. This is because the syntax and the tools 
      are unfamiliar. Your Hello World will be your first server-side program. Though the code is trivial, it can be tricky 
      to get it set up. The resulting HTML form your PHP program should be something like this:

      <html>
         <head>
            <title>Week 11 : Problem 1</title>
         </head>
         <body>
            <p>Hello World</p>
         </body>
      </html>

		-->
		
		<?php
		
		   echo "<p>Hello World</p>";
		
      ?>



	</body>
	
</html>