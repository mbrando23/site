<html>

	<head>
		<title>Problem 6: Text Manipulation</title>
	</head>
	
	<body>
		
		<!-- 
		
      PHP is designed to make many common web application tasks easy. As a result, there is a large collection of text 
      manipulation tools at our disposal. To demonstrate this, take a comma-separated list as a single text string and 
      display the result in a sorted table where each entry is on its own row. For example, if the input were:

      HTML, CSS, JavaScript, XML, DTD, XSL, AJAX, PHP, JQuery, JSON, CGI
      
      Then the output would look something like this:

      AJAX
      CGI
      CSS
      DTD
      HTML
      JQuery
      JSON
      JavaScript
      PHP
      XML
      XSL

		-->
		
		<?php
         
         $string = $_POST['input6'];	
         $substr = explode(", ", $string);
         
         sort($substr);

         $clength=count($substr);
         for($x=0;$x<$clength;$x++)
         {
            echo $substr[$x];
            echo "<br>";
         }
		
      ?>



	</body>
	
</html>