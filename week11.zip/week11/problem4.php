<html>

	<head>
		<title>Problem #4: Translate</title>
	</head>
	
	<body>
		
		<!-- 
      
      PHP has the ability to work with arrays. In fact, PHP arrays are similar to C++ arrays, vectors, and maps. 
      For this problem, you are to create an array similar to a C++ map. The index of the array will be the English 
      cardinals ("one", "two", .... "twenty") and the data of the array will be the Spanish cardinals 
      ("uno", "dos", ... "veinte"). If you do not speak Spanish, you may need to look up the first 20 Spanish cardinals 
      on the Internet.

      Your PHP program will accept the English cardinal from the user as a post method (much like Problem #3) and display 
      the equivilent Spanish cardinal:

      The word "one" in Spanish is "uno"

      If the user typed a word what is not between "one" and "twenty," then the following HTML will be generated:

      The English cardinal "twenty one" is not between "one" and "twenty"
		
		-->
		
		<?php
		
         $index = $_POST['input4'];
         
         $numbers = array("one"=>"uno", "two"=>"dos", "three"=>"tres", "four"=>"cuatro", "five"=>"cinco", "six"=>"seis",
         "seven"=>"siete", "eight"=>"ocho", "nine"=>"nueve", "ten"=>"diez", "eleven"=>"once", "twelve"=>"doce", 
         "thirteen"=>"trece", "fourteen"=>"catorce", "fifteen"=>"quince", "sixteen"=>"dieciséis", "seventeen"=>"diecisiete", 
         "eighteen"=>"dieciocho", "nineteen"=>"diecinueve", "twelve"=>"veinte");
                  
         if($numbers[$index])
         {
            echo "The translation of the number \"$index\" to Spanish is \"$numbers[$index]\".";            
         }         
         else
         {
            echo "The English cardinal \"$index\" is not between \"one\" and \"twenty\".";            
         }
                                   		
      ?>



	</body>
	
</html>