<html>

	<head>
		<title>Problem #5: Powers</title>
		<style>
      table, th, td {
         border: 1px solid black;
      }
      .right {
	      text-align: right;
      }
      </style>
	</head>
	
	<body>
		
		<!-- 
		
      Of course PHP is a full-featured language. This means it is possible to use standard language constructs such as 
      variables, loops, and arithmetic. Please demonstrate this by generating the powers table for a given number. 
      This PHP program will take two parameters: X and N. It will then generate an HTML table consisting of the first 
      N powers of X. Feel free to make the output as fancy as you like. A simplistic solution of the first 8 powers of 
      2 is:

      N	Xn
      1	2
      2	4
      3	8
      4	16
      5	32
      6	64
      7	128
      8	256

		-->
		
		<?php
		
         $n = $_POST['n'];
         $x = $_POST['x'];
         
		   echo "<h3>Powers of $x<sup>n</sup><h3> </br>";
		   
		   echo "<table><tr><th>power(n)</th><th>result</th></tr>";
         $res = 1;
         for ($i = 1; $i <= $n; ++$i) {
            $res *= $x;
            echo "<tr><td>$i</td><td class=\"right\">$res</td></tr>";
         }
         echo "</table>";
		   
		
      ?>



	</body>
	
</html>