function validateAge(ageId, theClass, x){
    var age = document.getElementById(ageId).value;
    if ((Number(age) && age >= 0 && age <= 118) || age == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


function validateSsn(ssnId, theClass, x){
    var ssn = document.getElementById(ssnId).value;
    var pos = ssn.search(/^ *\d{3}-\d{2}-\d{4} *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


function validateCard(cardId, theClass, x){
    var card = document.getElementById(cardId).value;
    var pos = card.search(/^ *\d{4} ?\d{4} ?\d{4} ?\d{4} *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


function validateDate(dateId, theClass, x){
    var date = document.getElementById(dateId).value;
    var pos = date.search(/^ *([1-9]|[1][0-2])\/(3[0-1]|[1-2][0-9]|[1-9])\/(175[3-9]|17[6-9][0-9]|1[8-9][0-9][0-9]|20[0-9][0-9]|2100) *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


function validateState(stateId, theClass, x){
    var state = document.getElementById(stateId).value;
    var pos = state.search(/^ *(A(L|K|R|Z)|C(A|O|T)|DE|FL|GA|HI|I(A|D|L|N)|K(S|Y)|LA|M(A|D|E|I|N|S|O|T)|N(E|V|H|J|M|Y|C|D)|O(H|K|R)|PA|RI|S(C|D)|T(N|X)|UT|V(T|A)|W(A|V|I|Y)) *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}

function validateMoney(moneyId, theClass, x){
    var money = document.getElementById(moneyId).value;
    var pos = money.search(/^ *\$(((([1-9]|[1-9][0-9]|[1-9][0-9][0-9]),([0-9][0-9][0-9]))|([1-9]|[1-9][0-9]|[1-9][0-9][0-9]))\.\d{2}) *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


