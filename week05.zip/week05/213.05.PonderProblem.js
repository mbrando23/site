function problem1() {
    console.log("\"Hello World\"");
}

function problem2(firstVar, secondVar) {
    var res = secondVar.replace(/RICH_GUY/g, firstVar);
    console.log(res);
}

function problem3(firstVar) {
    var res = (firstVar - 32) / 1.8;
    console.log(res.toFixed(1));
}

function problem4(firstVar) {    
    if (firstVar <= 0 || firstVar > 5)
        console.log("Invalid weight");
    else if(firstVar <= 1 && firstVar > 0)
        console.log("$0.98");
    else if(firstVar <= 2 && firstVar > 1)
        console.log("$1.19");
    else if(firstVar <= 3 && firstVar > 2)
        console.log("$1.40");
    else if(firstVar <= 4 && firstVar > 3)
        console.log("$1.61");
    else if(firstVar <= 5 && firstVar > 4)
        console.log("$1.82");                                   
}

function problem5(firstVar, secondVar, thirdVar) {
    var rate = Number(firstVar)/100;
    var term = Number(secondVar);
    var amount = Number(thirdVar); 
    for (var i = 0; i < term; i++){
        amount += amount*rate;
    }
    console.log("$" + amount.toFixed(2));
}