var calcus;
var cal = 0;
var cal1 = 0;
var cal2 = 0;
var cal3 = 0;
var cal4 = 0; 
var bodyText=["Palmeiras, you are unique, the best of the world.", "Too much skills and a good game.", "Get your points first, then you can win again.", "The first world champion.", "</p><p>A clear conscience is Palmeiras.", "What's another word for Porcooo?", "<h3>Palmeiras</h3><p>Experience is something we have."]

function generateText(sentenceCount){
   for (var i=0; i<sentenceCount; i++)
	   document.write(bodyText[Math.floor(Math.random()*7)]+" ")
}

function turnOpacity(theClass){ 
   document.getElementsByClassName("content-0")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName(theClass)[0].style.visibility = 'visible';   
}

function turnOpacityy(){ 
   document.getElementsByClassName("content-0")[0].style.visibility = 'visible'; 
   document.getElementsByClassName("content-1")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-2")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-3")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-4")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-5")[0].style.visibility = 'hidden';
   document.getElementsByClassName("content-6")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("content-7")[0].style.visibility = 'hidden';
   document.getElementsByClassName("content-")[0].style.visibility = 'hidden';     
}
 
function shoppingCart(){ 
   document.getElementsByClassName("content-7")[0].style.visibility = 'visible'; 
   document.getElementsByClassName("content-1")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-2")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-3")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-4")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-5")[0].style.visibility = 'hidden';
   document.getElementsByClassName("content-6")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("content-0")[0].style.visibility = 'hidden';
   document.getElementsByClassName("content-")[0].style.visibility = 'hidden';        
}

function prod(){ 
   document.getElementsByClassName("content-3")[0].style.visibility = 'visible'; 
   document.getElementsByClassName("content-1")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-2")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-7")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-4")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-5")[0].style.visibility = 'hidden';
   document.getElementsByClassName("content-6")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("content-0")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("content-")[0].style.visibility = 'hidden';     
}


function firstPage(){ 
   document.getElementsByClassName("content-")[0].style.visibility = 'visible'; 
   document.getElementsByClassName("content-1")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-2")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-7")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-4")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("content-5")[0].style.visibility = 'hidden';
   document.getElementsByClassName("content-6")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("content-0")[0].style.visibility = 'hidden';
   document.getElementsByClassName("cards")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("date")[0].style.visibility = 'hidden';
   document.getElementsByClassName("name")[0].style.visibility = 'hidden';
   document.getElementsByClassName("name")[1].style.visibility = 'hidden'; 
   document.getElementsByClassName("name")[2].style.visibility = 'hidden';  
   document.getElementsByClassName("num")[0].style.visibility = 'hidden';  
   document.getElementsByClassName("state")[0].style.visibility = 'hidden'; 
   document.getElementsByClassName("tel")[0].style.visibility = 'hidden';      
}

function validateCard(cardId, theClass, x){
    var card = document.getElementById(cardId).value;
    var pos = card.search(/^ *\d{4} ?\d{4} ?\d{4} ?\d{4} *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


function validateDate(dateId, theClass, x){
    var date = document.getElementById(dateId).value;
    var pos = date.search(/^ *([1-9]|[1][0-2])\/20[1-3][0-9] *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}
function calc(dataId, dataId2){
    var data1 = document.getElementById(dataId).value;
    var data2 = document.getElementById(dataId2).value;
    var calcu = data1 * data2;
    console.log(calcu);
    cal += calcu;
}

function calc1(dataId, dataId2){
    var data1 = document.getElementById(dataId).value;
    var data2 = document.getElementById(dataId2).value;
    var calcu1 = data1 * data2;
    console.log(calcu1);
    cal1 += calcu1;
}

function calc2(dataId, dataId2){
    var data1 = document.getElementById(dataId).value;
    var data2 = document.getElementById(dataId2).value;
    var calcu2 = data1 * data2;
    console.log(calcu2);
    cal2 += calcu2;
}

function calc3(dataId, dataId2){
    var data1 = document.getElementById(dataId).value;
    var data2 = document.getElementById(dataId2).value;
    var calcu3 = data1 * data2;
    console.log(calcu3);
    cal3 += calcu3;
}

function calc4(dataId, dataId2){
    var data1 = document.getElementById(dataId).value;
    var data2 = document.getElementById(dataId2).value;
    var calcu4 = data1 * data2;
    console.log(calcu4);
    cal4 += calcu4;
}


function myFunction() {
   calcus = cal + cal1 + cal2+ cal3 + cal4; 	
   document.getElementById("demo").innerHTML = "$" + calcus.toFixed(2);
}

function myReset() {
   cal = 0;
   cal1 = 0;
   cal2 = 0;
   cal3 = 0;
   cal4 = 0;    
   calcus = 0; 
   document.getElementById("demo").innerHTML = "$" + calcus.toFixed(2);	
}

function validateName(nameId, theClass, x){
    var name = document.getElementById(nameId).value;
    var pos = name.search(/^ *(([A-Z][a-z]* [A-Z][a-z]*)||([A-Z][a-z]*)) *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}

function validateNumber(numberId, theClass, x){
    var num = document.getElementById(numberId).value;
    var pos = num.search(/^ *\d+ *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}

function validateState(stateId, theClass, x){
    var state = document.getElementById(stateId).value;
    var pos = state.search(/^ *(A(L|K|R|Z)|C(A|O|T)|DE|FL|GA|HI|I(A|D|L|N)|K(S|Y)|LA|M(A|D|E|I|N|S|O|T)|N(E|V|H|J|M|Y|C|D)|O(H|K|R)|PA|RI|S(C|D)|T(N|X)|UT|V(T|A)|W(A|V|I|Y)) *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}

function validateTel(telId, theClass, x){
    var ssn = document.getElementById(telId).value;
    var pos = ssn.search(/^ *\d{3}-\d{3}-\d{4} *$/);
    if (pos == 0){
       document.getElementsByClassName(theClass)[x].style.visibility = 'hidden';
    }
    else {
       document.getElementsByClassName(theClass)[x].style.visibility = 'visible';    
    }
}


