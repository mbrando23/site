<html>

	<head>
		<title>Purchase Review</title>
		<link href="style.css" type="text/css" rel="stylesheet">
	</head>
	
	<body class="content">
		
		<!-- 
      2: Purchase Review
      Write a PHP program to return an HTML document which is a Purchase Review page. This will accept all the user 
      data from the initial form and present it to the user in an easy to understand way. The purchase review page 
      must have the following:

      Title & Headings: The page should be well formatted and organized with an appropriate title and headings. 
      The details of how you do this are up to you.
      Name: The user's first and last name.
      Address: The user's address, presented in an easy-to-read way.
      Phone: The user's phone number.
      Items: A list of the items selected for purchase and their respective costs.
      Total: The total cost of all the items being purchased.
      Payment: The credit card type and expiration date. Display the expiration date with month and year, such as
      "January 2013."
      Confirm & Cancel: At the bottom of the page, have a form element with an action element referencing the second 
      PHP program (the Confirmation Page). There will be two submit buttons: one to confirm the purchase and one to 
      cancel the purchase. Both of these will re-submit all the information presented on the Review Page.
		-->
		
		<h3>Purchase Review</h3>

      <p class="confirm">
         <?php
            $firstName = $_POST['name1'];
            $lastName = $_POST['name2'];
            $address1 = $_POST['name3'];
            $addressNum = $_POST['number1'];
            $state = $_POST['name4'];
            $telephone = $_POST['number2'];            
            echo $firstName . ' ' . $lastName . '<br>';  
            echo 'Str./Av. ' . $address1 . ', ' . $addressNum . ', ' . $state . '<br>';
            echo 'Tel. ' . $telephone;                         
         ?>      
      </p>
      
      <p>      
      <?php
         $card = $_POST['card'];
         $expiration = $_POST['expir'];         	
         $sub = explode("/", $expiration);
         /*         
         if(sub[0] == 12]) {
         	sub[0] = "December";
         }
         */
         echo "Credit card: $card <br>Expiration date: " . $expiration;     
      ?>            
      </p>

      <p>
         <?php
            $itens = $_POST['itens'];
            $total = $_POST['total'];                                                          
            echo "The purchase itens are: $itens <br>";
            echo "The total cost is $total" . "."         
         ?>
      </p>
      
      <form action="122.php" method="post">
         Please confirm your purchase:
         <button name="subject" type="submit" value="confirm">Confirm</button>
         <button name="subject" type="submit" value="cancel">Cancel</button>
      </form>


	</body>
	
</html>