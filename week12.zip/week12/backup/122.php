<html>

	<head>
		<title>Confirmation Page</title>
	</head>
	
	<body>
		
		<!-- 
      3: Confirmation Page
      Write a second PHP program to accept the data from the Purchase Review and display a simple message back to 
      the user. If this page was reached through the Confirm button on the Purchase Review, then return an HTML 
      document indicating that the purchase was complete. Note that if this were a real e-commerce site, the data 
      would be sent on to the order fulfillment software at this point. If this page was reached from the Cancel 
      button, then return an HTML document indicating that the purchase was canceled.
		-->
		
      <p>

      <?php


         echo "testing";

      ?>

      </p>

	</body>
	
</html>