var country = new XMLHttpRequest();
var studs = new XMLHttpRequest();

function first() {
   var text = "Choose the country and find out its biggest cities."
   document.getElementById("first").innerHTML = text;
}

function myFunction() {		
	if (document.getElementById("flag").value == "canada") {
      country.open('GET', 'canada.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.match(/[A-Za-z]( ?[A-Za-z])+/g);
         var num = cities.match(/\d{1,3}(,\d{3})*/g);
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + " city has " + num[1] + " inhabitants" + "</li>"; 	
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();      
   }
	if (document.getElementById("flag").value == "mexico") {
      country.open('GET', 'mexico.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.match(/[A-Za-z]( ?[A-Za-z])+/g);
         var num = cities.match(/\d{1,3}(,\d{3})*/g);
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + " city has " + num[1] + " inhabitants" + "</li>";
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();      
   }   

	if (document.getElementById("flag").value == "russia") {
      country.open('GET', 'russia.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.match(/[A-Za-z]( ?[A-Za-z])+/g);
         var num = cities.match(/\d{1,3}(,\d{3})*/g);
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + " city has " + num[1] + " inhabitants" + "</li>";
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();      
   }
   
	if (document.getElementById("flag").value == "usa") {
      country.open('GET', 'usa.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.match(/[A-Za-z]( ?[A-Za-z])+/g);
         var num = cities.match(/\d{1,3}(,\d{3})*/g);
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + " city has " + num[1] + " inhabitants" + "</li>";
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();
   }      

 }

function myFunction2() {
	
	if (document.getElementById("json").value == "json.txt") {
      studs.open('GET', '../json.txt');
      studs.onload = function () {  
      var stud = JSON.parse(studs.responseText);
      var text = "<ul>";
      for (var i = 0; i < 3; i++) {
         text += "<li>" + stud.students[i].first + " " + stud.students[i].last + " has the GPA of " 
         + stud.students[i].gpa + " from the following major: " + stud.students[i].major; 
         text += "</li>";
      }
      text += "</ul>";
      document.getElementById("students").innerHTML = text;
      };
      studs.send(); 
   }
   
   if (document.getElementById("json").value == "json1.txt") {
      studs.open('GET', '../json1.txt');
      studs.onload = function () {  
      var stud = JSON.parse(studs.responseText);
      var text = "<ul>";
      for (var i = 0; i < 7; i++) {
         text += "<li>" + stud.students[i].first + " " + stud.students[i].last + " has the GPA of " 
         + stud.students[i].gpa + " from the following major: " + stud.students[i].major; 
         text += "</li>";
      }
      text += "</ul>";
      document.getElementById("students").innerHTML = text;
      };
      studs.send(); 
   }
}


	
 

