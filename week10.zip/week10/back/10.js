var country = new XMLHttpRequest();
var list = new XMLHttpRequest();

function first() {
   var text = "Choose the country and find out its biggest cities."
   document.getElementById("first").innerHTML = text;
}

function myFunction() {		
	if (document.getElementById("flag").value == "canada") {     
      country.open('GET', 'canada.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.match(/[A-Za-z]( ?[A-Za-z])+/g);
         var num = cities.match(/\d{1,3}(,\d{3})*/g);
         var table = document.getElementById("myTable"); 
         for (var i = 0; i < city.length - 1; i++) {
            row = table.insertRow();
            cell1 = row.insertCell();
            cell2 = row.insertCell();
            cell1.innerHTML = city[i];
            cell2.innerHTML = num[i]; 
         }            
      };
      country.send();      
   }
	if (document.getElementById("flag").value == "mexico") {
      document.getElementById("myTable").style.display = '';  
      country.open('GET', 'mexico.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.split('\n');
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + "</li>"; 	
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();      
   }   

	if (document.getElementById("flag").value == "russia") {
		document.getElementById("myTable").style.visibility = 'hidden';  
      country.open('GET', 'russia.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.split('\n');
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + "</li>"; 	
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();      
   }
   
	if (document.getElementById("flag").value == "usa") {
		document.getElementById("myTable").style.display = 'none';  
      country.open('GET', 'usa.txt');
      country.onload = function () {  
         var cities = country.responseText;
         var city = cities.split('\n');
         var text = "<ul>";
         for (var i = 0; i < city.length - 1; i++) {
         text += "<li>" + city[i] + "</li>"; 	
         }   
         text += "</ul>";
         console.log(city[0]);
         document.getElementById("country").innerHTML = text;
      };
      country.send();
   }      

 }

function myFunction2() {
	list.open('GET', '../json.txt');
   list.onload = function () {  
   var students = list.responseText;   
   console.log(students);
   document.getElementById("students").innerHTML = students;
   };
   list.send();
 }
